<?php

namespace Core\general;

class Tools
{
    public static function encrypt(string $pass)
    {
        return (string)base64_encode(md5($pass, true));
    }
}

?>
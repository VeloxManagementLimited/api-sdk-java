<?php

namespace Core\api;

use Core\entity\RequestMethod;

abstract class VelotradeConnection
{

    protected $baseUrl;
    protected $username;
    protected $password;
    protected $token;
    protected $entityId;

    protected $loginRequest = null;

    public function __construct(string $baseUrl, string $user, string $pass, string $loginRequest)
    {
        $this->username = $user;
        $this->password = $pass;
        $this->baseUrl = $baseUrl;
        $this->loginRequest = $loginRequest;
        $this->token = $this->getAuthToken();
    }

    public function getBaseUrl()
    {
        return (string)$this->baseUrl;
    }

    public function getEntityId()
    {
        return (string)$this->entityId;
    }

    abstract protected function getAuthToken();

    public function query(string $method, string $request, $params = null, $contentType = null)
    {
        $resource = null;

        switch ($method) {
            case 'GET':
                if ($contentType != null)
                    $header[] = $contentType;
                $header[] = 'Authorization: ' . $this->token;
                $resource = curl_init($this->baseUrl . $request);
                curl_setopt($resource, CURLOPT_HTTPHEADER, $header);
                curl_setopt($resource, CURLOPT_RETURNTRANSFER, true);
                break;
            case 'POST':
                if ($contentType != null)
                    $header[] = $contentType;
                $header[] = 'Authorization: ' . $this->token;
                $resource = curl_init($this->baseUrl . $request);
                curl_setopt($resource, CURLOPT_POST, 1);
                curl_setopt($resource, CURLOPT_HTTPHEADER, $header);
                curl_setopt($resource, CURLOPT_POSTFIELDS, $params);
                curl_setopt($resource, CURLOPT_RETURNTRANSFER, true);
                break;
            default:
                break;
        }

        if ($resource != null) {
            $result = curl_exec($resource);
            return json_decode($result);
        } else {
            return false;
        }

    }

}

?>
<?php

namespace Core\api;


use Core\entity\Attachment;
use Core\entity\Auction;
use Core\entity\DebtorContact;
use Core\entity\Invoice;

class VelotradePrivateAPI
{

    private $baseUrl;
    private $username;
    private $password;

    const LOGIN_REQUEST = '/user/?fields=id,extraData';

    public function __construct($baseUrl, $username, $password)
    {
        $this->baseUrl = $baseUrl;
        $this->username = $username;
        $this->password = $password;
    }

    public function getAccounts() : array
    {
        $api = new VelotradePrivateConnection($this->baseUrl, $this->username, $this->password, self::LOGIN_REQUEST);
        $request = "/account/list/" . $api->getEntityId() . "?fields=currency,balance,availableBalance,transactions";
        print $request . "\n";
        $method = "GET";
        $contentType = "Content-type: application/json";
        $result = $api->query($method, $request, null, $contentType);

        if(isset($result->code) and isset($result->message)) {
            throw new \Exception($result->message);
        } else {
            if(isset($result->data)) {
                if(sizeof($result->data) > 0) {
                    return (array) $result->data;
                } else {
                    throw new \Exception('No accounts returned.');
                }
            } else {
                throw new \Exception('Could not get accounts.');
            }
        }
    }

    public function getAccount($accountId) {
        $api = new VelotradePrivateConnection($this->baseUrl, $this->username, $this->password, self::LOGIN_REQUEST);
        $request = "/account/$accountId?fields=availableBalance,balance";
        print_r($request);
        $method = "GET";
        $contentType = "Content-type: application/json";
        $result = $api->query($method, $request, null, $contentType);


        print $request . "\n";
        print_r($result);
    }


    //get available balance etc.
    public function getTransactions($accountId) {

        $api = new VelotradePrivateConnection($this->baseUrl, $this->username, $this->password, self::LOGIN_REQUEST);
        $request = "/account/$accountId/transactions?fields=status,type";
        $method = "GET";
        $contentType = "Content-type: application/json";
        $result = $api->query($method, $request, null, $contentType);


        print $request . "\n";
        print_r($result);

    }

    public function getDebtors() : array {
        $api = new VelotradePrivateConnection($this->baseUrl, $this->username, $this->password, self::LOGIN_REQUEST);
        $request = "/debtor/list";
        $method = "GET";
        $contentType = "Content-type: application/json";
        $result = $api->query($method, $request, null, $contentType);

        if(isset($result->code) and isset($result->message)) {
            throw new \Exception($result->message);
        } else {
            if(isset($result->data)) {
                if(sizeof($result->data) > 0) {
                    return (array) $result->data;
                } else {
                    throw new \Exception('No Debtors returned.');
                }
            } else {
                throw new \Exception('Could not get Debtors.');
            }
        }
    }

    public function getDebtorContacts() : array {
        $api = new VelotradePrivateConnection($this->baseUrl, $this->username, $this->password, self::LOGIN_REQUEST);
        $request = "/debtor/list?fields=contacts";
        $method = "GET";
        $contentType = "Content-type: application/json";
        $result = $api->query($method, $request, null, $contentType);

        if(isset($result->code) and isset($result->message)) {
            throw new \Exception($result->message);
        } else {
            if(isset($result->data)) {
                if(sizeof($result->data) > 0) {
                    return (array) $result->data;
                } else {
                    throw new \Exception('No Debtors returned.');
                }
            } else {
                throw new \Exception('Could not get Debtors.');
            }
        }
    }


    public function getDebtorContact(string $id): DebtorContact
    {

        $api = new VelotradePrivateConnection($this->baseUrl, $this->username, $this->password, self::LOGIN_REQUEST);

        $request = "/debtor/contact/$id?fields=name,email,phone,debtor.address,debtor.br,debtor.city,debtor.country,debtor.humanId,debtor.legalName,debtor.tradingName,debtor.website,debtor.zipCode";
        $method = "GET";
        $contentType = "Content-type: application/json";

        $result = $api->query($method, $request, null, $contentType);

        $d = new \Core\entity\Debtor();
        $dc = new \Core\entity\DebtorContact();
        $dc->setDebtor($d);

        $dc->setId($result->id);
        $dc->setEmail($result->email);
        $dc->setName($result->name);
        $dc->setPhone($result->phone);

        $d->setId($result->debtor->id);
        $d->setAddress($result->debtor->address);
        $d->setBr($result->debtor->br);
        $d->setCity($result->debtor->city);
        $d->setCountry($result->debtor->country);
        $d->setHumanId($result->debtor->humanId);
        $d->setLegalName($result->debtor->legalName);
        $d->setTradingName($result->debtor->tradingName);
        $d->setWebsite($result->debtor->website);
        $d->setZipCode($result->debtor->zipCode);

        return $dc;
    }

    public function createAuction(Auction $auction) : string
    {
        $content        = json_encode($auction->toArray());

        $api = new VelotradePrivateConnection($this->baseUrl, $this->username, $this->password, self::LOGIN_REQUEST);

        $request        = "/auction/";
        $method         = "POST";
        $params         = $content;
        $contentType    = 'content-type:application/json;charset=UTF-8';
        $result         = $api->query($method, $request, $params, $contentType);

        if(isset($result->id))
            return (string) $result->id;
        else {
            if(isset($result->message)) {
                throw new \Exception($result->message);
            } else {
                throw new \Exception('An error has occurred while creating an auction');
            }
        }
    }

    public function uploadAttachment(string $filePath): Attachment
    {
        $filename = basename($filePath);
        $file = new \CURLFile($filePath, mime_content_type($filePath), $filename);
        $api = new VelotradePrivateConnection($this->baseUrl, $this->username, $this->password, self::LOGIN_REQUEST);
        $request = "/attachment/";
        $method = "POST";
        $params = array('file' => $file, basename($filePath), $filename, 'entityId' => $api->getEntityId());
        $result = $api->query($method, $request, $params, null);
        if ($result != null) {
            if (isset($result->id)) {
                return new Attachment($result->id, $filename);
            } else {
                throw new \Exception("id not given");
            }
        } else {
            throw new \Exception("No result");
        }
    }

}
<?php

namespace Core\api;


use Core\entity\Attachment;
use Core\entity\Auction;
use Core\entity\DebtorContact;
use Core\entity\Invoice;

class VelotradePublicAPI
{

    private $baseUrl;
    private $username;
    private $password;

    const LOGIN_REQUEST = '/user/login';

    public function __construct($baseUrl, $username, $password)
    {
        $this->baseUrl = $baseUrl;
        $this->username = $username;
        $this->password = $password;
    }

    public function getDebtorContacts() : array {
        $api = new VelotradePublicConnection($this->baseUrl, $this->username, $this->password, self::LOGIN_REQUEST);
        $request = "/debtor/list";
        $method = "GET";
        $contentType = "Content-type: application/json";
        $result = $api->query($method, $request, null, $contentType);

        if(isset($result->code) and isset($result->message)) {
            throw new \Exception($result->message);
        } else {
            if(isset($result->data)) {
                if(sizeof($result->data) > 0) {
                    return (array) $result->data;
                } else {
                    throw new \Exception('No DebtorContacts returned.');
                }
            } else {
                throw new \Exception('Could not get DebtorContacts.');
            }
        }
    }

    // parameter passed is debtor cotnact id, not debtor
    public function getDebtorContact(string $id): DebtorContact
    {

        $api = new VelotradePublicConnection($this->baseUrl, $this->username, $this->password, self::LOGIN_REQUEST);
        $request = "/debtor/$id?fields=name,email,phone,debtor.address,debtor.br,debtor.city,debtor.country,debtor.humanId,debtor.legalName,debtor.tradingName,debtor.website,debtor.zipCode";
        $method = "GET";
        $contentType = "Content-type: application/json";

        $result = $api->query($method, $request, null, $contentType);

        $d = new \Core\entity\Debtor();
        $dc = new \Core\entity\DebtorContact();
        $dc->setDebtor($d);

        $dc->setId($result->id);
        $dc->setEmail($result->email);
        $dc->setName($result->name);
        $dc->setPhone($result->phone);

        $d->setId($result->debtor->id);
        $d->setAddress($result->debtor->address);
        $d->setBr($result->debtor->br);
        $d->setCity($result->debtor->city);
        $d->setCountry($result->debtor->country);
        $d->setHumanId($result->debtor->humanId);
        $d->setLegalName($result->debtor->legalName);
        $d->setTradingName($result->debtor->tradingName);
        $d->setWebsite($result->debtor->website);
        $d->setZipCode($result->debtor->zipCode);

        return $dc;
    }

    public function uploadAttachment(string $filePath): Attachment
    {
        $filename = basename($filePath);
        $file = new \CURLFile($filePath, mime_content_type($filePath), $filename);
        $api = new VelotradePublicConnection($this->baseUrl, $this->username, $this->password, self::LOGIN_REQUEST);
        $request = "/attachment/";
        $method = "POST";
        $params = array('file' => $file, basename($filePath), $filename, 'entityId' => $api->getEntityId());
        $result = $api->query($method, $request, $params, null);
        if ($result != null) {
            if (isset($result->id)) {
                return new Attachment($result->id, $filename);
            } else {
                throw new \Exception("id not given");
            }
        } else {
            throw new \Exception("No result");
        }
    }

    public function createAuction(Auction $auction) : string
    {
        $content        = json_encode($auction->toArray());

        $api = new VelotradePublicConnection($this->baseUrl, $this->username, $this->password, self::LOGIN_REQUEST);

        $request        = "/auction/";
        $method         = "POST";
        $params         = $content;
        $contentType    = 'content-type:application/json;charset=UTF-8';
        $result         = $api->query($method, $request, $params, $contentType);

        if(isset($result->id))
            return (string) $result->id;
        else {
            if(isset($result->message)) {
                throw new \Exception($result->message);
            } else {
                throw new \Exception('An error has occurred while creating an auction');
            }
        }
    }

    public function approveAuction(string $id) : bool
    {

        $content = array('auctionId' => $id);
        $api = new VelotradePublicConnection($this->baseUrl, $this->username, $this->password, self::LOGIN_REQUEST);
        $method = "POST";
        $request = "/$id/approve";
        $params = $content;

        $contentType = 'content-type:application/json;charset=UTF-8';

        $result         = $api->query($method, $request, $params, $contentType);

        if($result == null) {
            return (bool) true;
        } else {
            if(isset($result->message)) {
                throw new \Exception($result->message);
            } else {
                throw new \Exception('An error has occurred while approving the auction');
            }
        }

    }

    public function rejectAuction(string $id) : bool
    {
        $content = array('auctionId' => $id);
        $api = new VelotradePublicConnection($this->baseUrl, $this->username, $this->password, self::LOGIN_REQUEST);
        $method = "POST";
        $request = "/$id/reject";
        $params = $content;

        $contentType = 'content-type:application/json;charset=UTF-8';

        $result         = $api->query($method, $request, $params, $contentType);

        if($result == null) {
            return (bool) true;
        } else {
            if(isset($result->message)) {
                throw new \Exception($result->message);
            } else {
                throw new \Exception('An error has occurred while approving the auction');
            }
        }
    }

    public function getAuctionStatus(string $id) : string
    {
        $api = new VelotradePublicConnection($this->baseUrl, $this->username, $this->password, self::LOGIN_REQUEST);
        $request = "/auction/$id?fields=status";
        $method = "GET";
        $contentType = "Content-type: application/json";
        $result = $api->query($method, $request, null, $contentType);
        if(isset($result->status))
            return (string) $result->status;
        else {
            if(isset($result->message)) {
                throw new \Exception($result->message);
            } else {
                throw new \Exception('An error has occurred while getting the auction status');
            }
        }
    }

}
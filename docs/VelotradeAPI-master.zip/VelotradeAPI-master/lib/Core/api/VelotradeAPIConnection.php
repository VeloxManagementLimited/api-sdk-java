<?php

namespace Core\api;

use Core\entity\RequestMethod;

class VelotradeAPIConnection
{

    private $baseUrl;
    private $username;
    private $password;
    private $token;
    private $entityId;

    const USER_LOGIN = "/user/login";

    public function __construct(string $baseUrl, string $user, string $pass)
    {
        $this->username = $user;
        $this->password = $pass;
        $this->baseUrl = $baseUrl;
        $this->token = $this->getAuthToken();
    }

    public function getBaseUrl()
    {
        return (string)$this->baseUrl;
    }

    public function getEntityId()
    {
        return (string)$this->entityId;
    }

    private function getAuthToken()
    {
        $header[] = 'Content-type: application/json';
        $header[] = 'Authorization: Velox_' . $this->username . ":" . $this->password;

        $result = null;

        try {
            $resource = curl_init($this->getBaseUrl() . self::USER_LOGIN);
            curl_setopt($resource, CURLOPT_HTTPHEADER, $header);
            curl_setopt($resource, CURLOPT_RETURNTRANSFER, true);
            $result = curl_exec($resource);
        } catch (Exception $e) {
            throw new Exception("Error in the curl library.");
        }

        $result = json_decode($result);

        if (isset($result->extraData)) {
            $this->entityId = $result->id;
            return (string)$result->extraData->auth;
        } else {
            if (isset($result->message)) {
                throw new Exception($result->message);
            } else
                throw new Exception("Could not get a token.");
        }

    }

    public function query(string $method, string $request, $params = null, $contentType = null)
    {
        $resource = null;

        switch ($method) {
            case 'GET':
                if ($contentType != null)
                    $header[] = $contentType;
                $header[] = 'Authorization: ' . $this->token;
                $resource = curl_init($this->baseUrl . $request);
                curl_setopt($resource, CURLOPT_HTTPHEADER, $header);
                curl_setopt($resource, CURLOPT_RETURNTRANSFER, true);
                break;
            case 'POST':
                if ($contentType != null)
                    $header[] = $contentType;
                $header[] = 'Authorization: ' . $this->token;
                $resource = curl_init($this->baseUrl . $request);
                curl_setopt($resource, CURLOPT_POST, 1);
                curl_setopt($resource, CURLOPT_HTTPHEADER, $header);
                curl_setopt($resource, CURLOPT_POSTFIELDS, $params);
                curl_setopt($resource, CURLOPT_RETURNTRANSFER, true);
                break;
            default:
                break;
        }

        if ($resource != null) {
            $result = curl_exec($resource);
            return json_decode($result);
        } else {
            return false;
        }

    }

}

?>
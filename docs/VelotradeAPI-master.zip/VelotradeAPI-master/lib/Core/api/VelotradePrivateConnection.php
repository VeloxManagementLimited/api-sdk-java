<?php


namespace Core\api;

use Core\entity\RequestMethod;

class VelotradePrivateConnection extends VelotradeConnection
{

    public function __construct($baseUrl, $user, $pass, $loginRequest)
    {
        parent::__construct($baseUrl, $user, $pass, $loginRequest);
    }

    protected function getAuthToken()
    {
        $header[] = 'Content-type: application/json';
        $header[] = 'Authorization: Velox_' . $this->username . ":" . $this->password;

        $result = null;

        try {
            $resource = curl_init($this->getBaseUrl() . $this->loginRequest);
            curl_setopt($resource, CURLOPT_HTTPHEADER, $header);
            curl_setopt($resource, CURLOPT_RETURNTRANSFER, true);
            $result = curl_exec($resource);
        } catch (\Exception $e) {
            throw new \Exception("Error in the curl library.");
        }

        $result = json_decode($result);

        if (isset($result->extraData)) {
            $this->entityId = $result->id;
            return (string)$result->extraData->auth;
        } else {
            if (isset($result->message)) {
                throw new \Exception($result->message);
            } else
                throw new \Exception("Could not get a token.");
        }

    }

}
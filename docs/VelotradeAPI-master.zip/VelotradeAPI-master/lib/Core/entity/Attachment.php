<?php

namespace Core\entity;


class Attachment {
    private $id;
    private $name;

    public function __construct($id, $name)
    {
        $this->id = $id;
        $this->name = $name;
    }

    public function getId()
    {
        return (string) $this->id;
    }

    public function setId(string $id)
    {
        $this->id = $id;
    }

    public function getName()
    {
        return (string) $this->name;
    }

    public function setName(string $name)
    {
        $this->name = $name;
    }

    public function toArray() {
        return (array) get_object_vars($this);
    }
}
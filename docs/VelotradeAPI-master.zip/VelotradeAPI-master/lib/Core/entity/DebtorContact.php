<?php


namespace Core\entity;


class DebtorContact {

    private $id;
    private $email;
    private $name;
    private $phone;
    private $debtor;

    public function getId()
    {
        return $this->id;
    }

    public function setId($id)
    {
        $this->id = $id;
    }

    public function getEmail()
    {
        return $this->email;
    }

    public function setEmail($email)
    {
        $this->email = $email;
    }

    public function getName()
    {
        return $this->name;
    }

    public function setName($name)
    {
        $this->name = $name;
    }

    public function getPhone()
    {
        return $this->phone;
    }

    public function setPhone($phone)
    {
        $this->phone = $phone;
    }

    public function getDebtor()
    {
        return $this->debtor;
    }

    public function setDebtor($debtor)
    {
        $this->debtor = $debtor;
    }

    public function toArray() {
        $a = (array) get_object_vars($this);
        $a['debtor'] = $this->getDebtor()->toArray();
        return $a;
    }

}
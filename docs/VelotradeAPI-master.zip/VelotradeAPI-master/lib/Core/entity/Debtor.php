<?php

namespace Core\entity;


class Debtor {

    private $id;            // id
    private $address;       // address
    private $br;            // business registration
    private $city;          // city
    private $country;       // country
    private $humanId;       // human id
    private $legalName;     // legal name
    private $tradingName;   // trading name
    private $website;       // homepage
    private $zipCode;       // zip code


    public function getId()
    {
        return (string) $this->id;
    }

    public function setId(string $id)
    {
        $this->id = $id;
    }

    public function getAddress()
    {
        return (string) $this->address;
    }

    public function setAddress(string $address)
    {
        $this->address = $address;
    }

    public function getBr()
    {
        return (string) $this->br;
    }

    public function setBr(string $br)
    {
        $this->br = $br;
    }

    public function getCity()
    {
        return (string) $this->city;
    }

    public function setCity(string $city)
    {
        $this->city = $city;
    }

    public function getCountry()
    {
        return (string) $this->country;
    }

    public function setCountry(string $country)
    {
        $this->country = $country;
    }

    public function getHumanId()
    {
        return (string) $this->humanId;
    }

    public function setHumanId(string $humanId)
    {
        $this->humanId = $humanId;
    }

    public function getLegalName()
    {
        return (string) $this->legalName;
    }

    public function setLegalName(string $legalName)
    {
        $this->legalName = $legalName;
    }

    public function getTradingName()
    {
        return (string) $this->tradingName;
    }

    public function setTradingName(string $tradingName)
    {
        $this->tradingName = $tradingName;
    }

    public function getWebsite()
    {
        return (string) $this->website;
    }

    public function setWebsite(string $website)
    {
        $this->website = $website;
    }

    public function getZipCode()
    {
        return (string) $this->zipCode;
    }

    public function setZipCode(string $zipCode)
    {
        $this->zipCode = $zipCode;
    }

    public function toArray() {
        return (array) get_object_vars($this);
    }
}
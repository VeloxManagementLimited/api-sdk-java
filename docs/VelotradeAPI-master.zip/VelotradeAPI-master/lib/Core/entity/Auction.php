<?php

namespace Core\entity;

class Auction {

    // Primary Debtor object
    private $debtor;                    // Debtor object

    // Debtor contact
    private $debtorName;                // debtor contact name
    private $debtorEmail;               // debtor contact email
    private $debtorPhone;               // debtor contact phone

    // invoice

    private $number;                    // invoice number
    private $issueDate;                 // ISO issue date
    private $currency;                  // currency USD for example
    private $amount;                    // invoice value
    private $expectedAmount;            // expected amount
    private $paymentTerms;              // duration in days
    private $dueDate;                   // date ISO
    private $expectedPaymentDate;       // date ISO
    private $description;               // invoice description

    private $invoice;                   // Attachment object
    private $transportationDocument;     // Attachment object
    private $purchaseOrder;             // Attachment object

    public function __construct(DebtorContact $debtorContact, Invoice $invoice, Attachment $invoiceDocument, Attachment $transporationDocument, Attachment $purchaseOrder )
    {

        // debtor
        $this->setDebtor($debtorContact->getDebtor()->toArray());

        // debtorcontact
        $this->setDebtorName($debtorContact->getName());
        $this->setDebtorEmail($debtorContact->getEmail());
        $this->setDebtorPhone($debtorContact->getPhone());

        // invoice
        $this->setNumber($invoice->getNumber());
        $this->setIssueDate($invoice->getIssueDate());
        $this->setCurrency($invoice->getCurrency());
        $this->setAmount($invoice->getAmount());
        $this->setExpectedAmount($invoice->getExpectedAmount());
        $this->setPaymentTerms($invoice->getPaymentTerms());
        $this->setDueDate($invoice->getDueDate());
        $this->setExpectedPaymentDate($invoice->getExpectedPaymentDate());
        $this->setDescription($invoice->getDescription());

        // Attachments

        $this->setInvoice($invoiceDocument->toArray());
        $this->setTransporationDocument($transporationDocument->toArray());
        $this->setPurchaseOrder($purchaseOrder->toArray());

    }

    public function getDebtor()
    {
        return $this->debtor;
    }

    public function setDebtor(array $debtor)
    {
        $this->debtor = $debtor;
    }

    public function getDebtorName()
    {
        return $this->debtorName;
    }

    public function setDebtorName($debtorName)
    {
        $this->debtorName = $debtorName;
    }

    public function getDebtorEmail()
    {
        return $this->debtorEmail;
    }

    public function setDebtorEmail($debtorEmail)
    {
        $this->debtorEmail = $debtorEmail;
    }

    public function getDebtorPhone()
    {
        return $this->debtorPhone;
    }

    public function setDebtorPhone($debtorPhone)
    {
        $this->debtorPhone = $debtorPhone;
    }

    public function getNumber()
    {
        return $this->number;
    }

    public function setNumber($number)
    {
        $this->number = $number;
    }

    public function getIssueDate()
    {
        return $this->issueDate;
    }

    public function setIssueDate($issueDate)
    {
        $this->issueDate = $issueDate;
    }

    public function getCurrency()
    {
        return $this->currency;
    }

    public function setCurrency($currency)
    {
        $this->currency = $currency;
    }

    public function getAmount()
    {
        return $this->amount;
    }

    public function setAmount($amount)
    {
        $this->amount = $amount;
    }

    public function getExpectedAmount()
    {
        return $this->expectedAmount;
    }

    public function setExpectedAmount($expectedAmount)
    {
        $this->expectedAmount = $expectedAmount;
    }

    public function getPaymentTerms()
    {
        return $this->paymentTerms;
    }

    public function setPaymentTerms($paymentTerms)
    {
        $this->paymentTerms = $paymentTerms;
    }

    public function getDueDate()
    {
        return $this->dueDate;
    }

    public function setDueDate($dueDate)
    {
        $this->dueDate = $dueDate;
    }

    public function getExpectedPaymentDate()
    {
        return $this->expectedPaymentDate;
    }

    public function setExpectedPaymentDate($expectedPaymentDate)
    {
        $this->expectedPaymentDate = $expectedPaymentDate;
    }

    public function getDescription()
    {
        return $this->description;
    }

    public function setDescription($description)
    {
        $this->description = $description;
    }

    public function getInvoice()
    {
        return $this->invoice;
    }

    public function setInvoice($invoice)
    {
        $this->invoice = $invoice;
    }

    public function getTransportationDocument()
    {
        return $this->transportationDocument;
    }

    public function setTransporationDocument($transportationDocument)
    {
        $this->transportationDocument = $transportationDocument;
    }

    public function getPurchaseOrder()
    {
        return $this->purchaseOrder;
    }

    public function setPurchaseOrder($purchaseOrder)
    {
        $this->purchaseOrder = $purchaseOrder;
    }

    public function toArray() {
        return (array) get_object_vars($this);
    }

}
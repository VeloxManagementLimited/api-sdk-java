<?php

namespace Core\entity;

class Invoice
{

    private $number;
    private $issueDate;
    private $currency;
    private $amount;
    private $expectedAmount;
    private $paymentTerms;
    private $dueDate;
    private $expectedPaymentDate;
    private $description;

    public function getNumber()
    {
        return (string) $this->number;
    }

    public function setNumber(string $number)
    {
        $this->number = $number;
    }

    public function getIssueDate()
    {
        return (string) $this->issueDate;
    }

    public function setIssueDate(string $issueDate)
    {
        $this->issueDate = $issueDate;
    }

    public function getCurrency()
    {
        return (string) $this->currency;
    }

    public function setCurrency(string $currency)
    {
        $this->currency = $currency;
    }

    public function getAmount()
    {
        return (float) $this->amount;
    }

    public function setAmount(float $amount)
    {
        $this->amount = $amount;
    }

    public function getExpectedAmount()
    {
        return (float) $this->expectedAmount;
    }

    public function setExpectedAmount(float $expectedAmount)
    {
        $this->expectedAmount = $expectedAmount;
    }

    public function getPaymentTerms()
    {
        return (integer) $this->paymentTerms;
    }

    public function setPaymentTerms(int $paymentTerms)
    {
        $this->paymentTerms = $paymentTerms;
    }

    public function getDueDate()
    {
        return (string) $this->dueDate;
    }

    public function setDueDate(string $dueDate)
    {
        $this->dueDate = $dueDate;
    }

    public function getExpectedPaymentDate()
    {
        return (string) $this->expectedPaymentDate;
    }

    public function setExpectedPaymentDate(string $expectedPaymentDate)
    {
        $this->expectedPaymentDate = $expectedPaymentDate;
    }

    public function getDescription()
    {
        return (string) $this->description;
    }

    public function setDescription(string $description)
    {
        $this->description = $description;
    }

    public function toArray() {
        return (array) get_object_vars($this);
    }

}
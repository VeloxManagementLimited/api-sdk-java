<?php

class AutoLoader {
    function __construct() {
        spl_autoload_register(
            function( $class ) {
                $class = preg_replace("/\\\\/","/", $class);
                include_once $class . '.php';
            }
        );
    }
}

?>
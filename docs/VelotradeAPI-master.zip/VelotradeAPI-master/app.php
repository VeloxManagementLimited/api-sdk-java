<?php


require_once 'lib/AutoLoader.php';

$autoloader = new AutoLoader();

$baseUrl = "https://devapi.velotrade.com";
//$baseUrl = "http://development-velotrade.ap-southeast-1.elasticbeanstalk.com/api/public";
$username = "robin.walser+sel1@me.com";
$password = "LBlN/DMcGA/NnI7WQot3qg==";

$createAuction = false;


use Core\api\VelotradePublicAPI;
use \Core\entity\Invoice;
use \Core\entity\Auction;

$api = new VelotradePublicAPI($baseUrl, $username, $password);



$a = $api->getDebtorContacts();


foreach($a as $r) {
    print $r->id . "\n";
}


// GET DEBTOR (works)

$id = "oa1a6a170-d3d4-428a-835f-35ab021d410c";
$debtorContact = $api->getDebtorContact($id);
print_r($debtorContact);

// UPLOAD FILE

$file = "/Users/robinwalser/Velotrade/Blank.pdf";
$attachment = $api->uploadAttachment($file);
print_r($attachment);

// CREATE Auction

if($createAuction) {

    $invoice = new Invoice();

    $invoice->setNumber("TEST");
    $invoice->setIssueDate("2017-09-28T16:00:00.000Z");
    $invoice->setCurrency("USD");
    $invoice->setAmount(10000);
    $invoice->setExpectedAmount(10000);
    $invoice->setPaymentTerms(6000);
    $invoice->setDueDate("2017-11-27T16:00:00.000Z");
    $invoice->setExpectedPaymentDate("2017-11-27T16:00:00.000Z");
    $invoice->setDescription("TEST");

    try {
        $auction = new Auction($debtorContact, $invoice, $attachment, $attachment, $attachment);
        $auctionId = $api->createAuction($auction);
        print_r($auctionId);
    } catch (Exception $e) {
        print $e->getMessage();
    }

}
// Auction Status

$auctionId = "t6bba8cd6-5cd0-489a-8452-e3e351337755";


$id = $api->getAuctionStatus($auctionId);


print_r($id);

try {
    $api->approveAuction($auctionId);
} catch(Exception $e) {
    print $e->getMessage();
}


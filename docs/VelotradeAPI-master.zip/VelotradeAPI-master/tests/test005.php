<?php


require_once '../lib/AutoLoader.php';

$autoloader = new AutoLoader();

$baseUrl = "https://devapi.velotrade.com";
$username = "robin.walser+sel1@me.com";
$password = "LBlN/DMcGA/NnI7WQot3qg==";

$debtor = new Core\entity\Debtor();

$debtor->setId("e285d834e-b8d5-40f4-9dfa-6380b3d0788e");
$debtor->setAddress("ASDF");
$debtor->setBr("BR123123");
$debtor->setCity("Zurich");
$debtor->setCountry("CH");
$debtor->setHumanId("D57");
$debtor->setLegalName("Cement AG");
$debtor->setTradingName("Cement AG");
$debtor->setWebsite("http://www.cement123456.com");
$debtor->setZipCode("ASDF");





$v = new \Core\api\VelotradeAPIConnection($baseUrl, $username, $password);

$a = $v->query("GET", "/debtor/list?fields=name,email,phone,debtor.address,debtor.br,debtor.city,debtor.country,debtor.humanId,debtor.legalName,debtor.tradingName,debtor.website,debtor.zipCode", null, 'Content-type: application/json');


$search = 'oa1a6a170-d3d4-428a-835f-35ab021d410c';

$d = new \Core\entity\Debtor();
$dc = new \Core\entity\DebtorContact();
$dc->setDebtor($d);

foreach($a->data as $record) {
    if($record->id == $search) {

        $dc->setId($record->id);
        $dc->setEmail($record->email);
        $dc->setName($record->name);
        $dc->setPhone($record->phone);

        $d->setId($record->debtor->id);
        $d->setAddress($record->debtor->address);
        $d->setBr($record->debtor->br);
        $d->setCity($record->debtor->city);
        $d->setCountry($record->debtor->country);
        $d->setHumanId($record->debtor->humanId);
        $d->setLegalName($record->debtor->legalName);
        $d->setTradingName($record->debtor->tradingName);
        $d->setWebsite($record->debtor->website);
        $d->setZipCode($record->debtor->zipCode);
        break;
    }
}

print_r($dc->toArray());


// get debtor contact by id 'oa1a6a170-d3d4-428a-835f-35ab021d410c'


// seller approve auction
//
//$content = array('auctionId' => 'ta3f1ff5e-d6ec-4810-9f65-955c8ad72ab8');
//$content = json_encode($content);
//
//$a = $v->query("POST", "/ta3f1ff5e-d6ec-4810-9f65-955c8ad72ab8/approve", $content, 'content-type:application/json;charset=UTF-8');
//
//
//print_r($a);


/***
 *
 * stdClass Object
(
[code] => ERROR
[message] => WRONG STATE
)
 */
<?php

$baseUrl = "https://devapi.velotrade.com";

$username = "robin.walser+sel1@me.com";
$password = "LBlN/DMcGA/NnI7WQot3qg==";


try {
    // Initialize
    $v = new VelotradeAPI($baseUrl, $username, $password);

   $ret = $v->query(RequestMethod::GET, "/debtor/list?fields=name,debtor,debtor.legalName");
    print_r($ret);




    // Attachment
    // todo: file get contents return boolean check if file exists first
    /*$file = new CURLFile('/Users/robinwalser/Test.pdf', "application/pdf", "Test.pdf");
    $params = array('file' => $file, 'description', 'Test1', 'entityId' => $v->getEntityId());
    $ret = $v->query(RequestMethod::POST, "/attachment/", $params);
    print_r($ret);
    $file_id = $ret->id;
    var_dump($file_id);*/

    // Create auction
//
//    $params = array(
//
//        'amount' => '123',
//        'invoice' => $fileId,
//        'transportationDocument' => $fileId,
//        'purchaseOrder' => $fileId,
//    );


    $a = file_get_contents('/Users/robinwalser/auction.json');

    var_dump($a);

    $ret = $v->query(RequestMethod::POST, "/auction/", $a);

    print_r(json_decode($a));

    print_r($ret);


} catch (Exception $e) {
    print $e->getMessage();
}

class RequestMethod
{
    const GET = "GET";
    const POST = "POST";
    const PUT = "PUT";
    const PATCH = "PATCH";
    const DELETE = "DELETE";
}

// TEST AREA
//
//
//curl_setopt($ch, CURLOPT_POST, 1);
//curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
//curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//$result = curl_exec($ch);
//
//curl_close($ch);
//
//
//print_r($result);


// todo: try to use debtorcontact that has not been approved yet to create an auction

class VelotradeAPI
{

    private $baseUrl;
    private $username;
    private $password;
    private $token;
    private $entityId;

    const USER_LOGIN = "/user/login";

    public function __construct(string $baseUrl, string $user, string $pass)
    {
        $this->username = $user;
        $this->password = $pass;
        $this->baseUrl = $baseUrl;
        $this->token = $this->getAuthToken();
    }

    public function getBaseUrl()
    {
        return (string)$this->baseUrl;
    }

    public function getEntityId()
    {
        return (string)$this->entityId;
    }

    private function getAuthToken()
    {
        $header[] = 'Content-type: application/json';
        $header[] = 'Authorization: Velox_' . $this->username . ":" . $this->password;

        $result = null;

        try {
            $resource = curl_init($this->getBaseUrl() . self::USER_LOGIN);
            curl_setopt($resource, CURLOPT_HTTPHEADER, $header);
            curl_setopt($resource, CURLOPT_RETURNTRANSFER, true);
            $result = curl_exec($resource);
        } catch (Exception $e) {
            throw new Exception("Error in the curl library.");
        }

        $result = json_decode($result);

        if (isset($result->extraData)) {
            $this->entityId = $result->id;
            return (string)$result->extraData->auth;
        } else {
            if (isset($result->message)) {
                throw new Exception($result->message);
            } else
                throw new Exception("Could not get a token.");
        }
    }

    public function query(string $method, string $request, $params = null)
    {
        $resource = null;

        if ($method == RequestMethod::GET) {
            $header[] = 'Content-type: application/json';
            $header[] = 'Authorization: ' . $this->token;
            $resource = curl_init($this->baseUrl . $request);
            // needed if output required
            curl_setopt($resource, CURLINFO_HEADER_OUT, true);
            curl_setopt($resource, CURLOPT_HTTPHEADER, $header);
            curl_setopt($resource, CURLOPT_RETURNTRANSFER, true);
        } else if ($method == RequestMethod::POST) {

            $header[] = 'content-type:application/json;charset=UTF-8';
            $header[] = 'Authorization: ' . $this->token;
            $resource = curl_init($this->baseUrl . $request);
            curl_setopt($resource, CURLINFO_HEADER_OUT, true);
            curl_setopt($resource, CURLOPT_POST, 1);
            curl_setopt($resource, CURLOPT_HTTPHEADER, $header);
            curl_setopt($resource, CURLOPT_POSTFIELDS, $params);
            curl_setopt($resource, CURLOPT_RETURNTRANSFER, true);
        }

        if ($resource != null) {
            $result = curl_exec($resource);
            var_dump(curl_getinfo($resource, CURLINFO_HEADER_OUT));
            return json_decode($result);
        } else {
            return false;
        }


    }


}

class Tools
{
    public static function encrypt(string $pass)
    {
        return (string)base64_encode(md5($pass, true));
    }
}

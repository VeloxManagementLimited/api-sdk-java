<?php

require_once '../lib/AutoLoader.php';

$autoloader = new AutoLoader();

$baseUrl = "http://development-velotrade.ap-southeast-1.elasticbeanstalk.com/api/";
$username = "robin.walser+sel1@me.com";
$password = "LBlN/DMcGA/NnI7WQot3qg==";

use Core\api\VelotradePrivateAPI;
use \Core\entity\Invoice;
use \Core\entity\Auction;

$api = new VelotradePrivateAPI($baseUrl, $username, $password);


$a = $api->getDebtors();
//print_r($a);

$a = $api->getDebtorContacts();
//print_r($a);

$file = "/Users/robinwalser/Velotrade/Blank.pdf";
$attachment = $api->uploadAttachment($file);


$attachmentId = "ada5c45f8-2544-428a-abc3-cf48dd893332";


// get attachment


$debtorContactId = "oaf84fbe7-c30c-48f5-8a91-d52666b3ee91";
$debtorContact = $api->getDebtorContact($debtorContactId);
print_r($debtorContact->toArray());




$invoice = new Invoice();

$invoice->setNumber("TEST");
$invoice->setIssueDate("2017-09-28T16:00:00.000Z");
$invoice->setCurrency("USD");
$invoice->setAmount(10000);
$invoice->setExpectedAmount(10000);
$invoice->setPaymentTerms(6000);
$invoice->setDueDate("2017-11-27T16:00:00.000Z");
$invoice->setExpectedPaymentDate("2017-11-27T16:00:00.000Z");
$invoice->setDescription("TEST");

try {
    $auction = new Auction($debtorContact, $invoice, $attachment, $attachment, $attachment);
    $auctionId = $api->createAuction($auction);
    print_r($auctionId);
} catch (Exception $e) {
    print $e->getMessage();
}


?>
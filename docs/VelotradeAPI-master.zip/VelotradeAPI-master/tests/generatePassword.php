<?php



require_once '../lib/AutoLoader.php';

$autoloader = new AutoLoader();
use \Core\general\Tools;

$password = "Montrichard$123456";

$a = Tools::encrypt($password);


print $a;

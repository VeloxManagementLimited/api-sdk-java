<?php

$url = '/Users/robinwalser/auction.json';

$str = file_get_contents($url);

//$str[1] = '"';
//$str[2] = 's';
//$str[3] = 's';

//print PHP_EOL;
//
//for($i = 0; $i < strlen($str); $i++)
//    print "[$i] = " . $str[$i] . "\n";
//
//print PHP_EOL;

print_r(json_decode($str));


print json_last_error_msg();


print "\n";
print json_encode(json_decode($str));

print "\n";
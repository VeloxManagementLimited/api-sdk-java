<?php


require_once '../lib/AutoLoader.php';

$autoloader = new AutoLoader();

$baseUrl = "https://devapi.velotrade.com";
$username = "robin.walser+sel1@me.com";
$password = "LBlN/DMcGA/NnI7WQot3qg==";

$createAuction = false;


use Core\api\VelotradeConnection;
